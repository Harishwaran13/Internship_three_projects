<!DOCTYPE HTML>  
<html>
<head>
  <link rel="stylesheet" type="text/css" href="Lab9.css">
</head>
<body>  
<h2>Registration</h2>
<form method="post" action="Lab9_data.php">  
  Name: <input type="text" name="name">
  <br><br>
  E-mail: <input type="text" name="email">
  <br><br>
  Mobile: <input type="text" name="website">
  <br><br>
   Comment: <textarea name="comment" rows="5" cols="40"></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <br><br>
  <input type="checkbox" name="Remember" value="Remember">Remember Me
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>



</body>
</html>
